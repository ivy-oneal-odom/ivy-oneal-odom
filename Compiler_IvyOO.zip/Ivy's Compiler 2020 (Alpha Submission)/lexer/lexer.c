/* Starter code provided to students */

/* The lexical analyzer for the C-- Programming Language
 */
// TODO: you are welcome to completely wipe out the contents of this
// file and start from scratch, or use this as your starting point.

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <ctype.h>
#include "lexer.h"


// these are likely values that will be needed by the parser, so 
// making them global variables is okay
char lexbuf[MAXLEXSIZE];  // stores current lexeme
int  tokenval=0;          // stores current token's value
                          // (might not be used for every token)
int  src_lineno=0;        // current line number in source code input

// function prototypes:
static void print_lineno();  // static limits its scope to only in this .c file

tokenT handle_error(char c){
	switch(c){
		case EOF:
			return DONE;
		default:
			return LEXERROR;
	}
}

void single_line_comment(FILE* fd){
	char c = getc(fd);

	if(c == '\n'){
		return;
	}
	
	single_line_comment(fd);
}

void multi_line_comment(FILE* fd){
	char c = getc(fd);

	if(c == '*'){
		if(getc(fd) == '/'){
			return;
		}
	}

	multi_line_comment(fd);
}

tokenT O(FILE *fd){
	char c = getc(fd);

	if(c == '/'){
		char new_c = getc(fd);
		if(new_c == '/'){
			single_line_comment(fd);
		}else if(new_c == '*'){
			multi_line_comment(fd);
		}else{
			ungetc(new_c, fd);
		}
	}

	if(isspace(c)){
		return O(fd);
	}

	if(c == '='){
		return EQ;
	}else{
		ungetc(c, fd);
		return ASSIGN;
	}
}

tokenT M(FILE *fd, char old_c, int special){
	char c = getc(fd);

	if(c == '/'){
		char new_c = getc(fd);
		if(new_c == '/'){
			single_line_comment(fd);
		}else if(new_c == '*'){
			multi_line_comment(fd);
		}else{
			ungetc(new_c, fd);
		}
	}
	
	if(isspace(c)){
		return M(fd, old_c, special);
	}

	if(c == '\''){
		if(special){
			tokenval = -1;
		}else{
			tokenval = old_c;
		}
		return NUM;
	}else{
		return handle_error(c);
	}
}

tokenT B(FILE *fd, char *string){
	char c = getc(fd);

	if(c == '/'){
		char new_c = getc(fd);
		if(new_c == '/'){
			single_line_comment(fd);
		}else if(new_c == '*'){
			multi_line_comment(fd);
		}else{
			ungetc(new_c, fd);
		}
	}

	if(isalpha(c) || isdigit(c) || c == '_'){
		char temp_string[2] = {c, '\0'};
		strcat(string, temp_string);
		return B(fd, string);
	}else{
		ungetc(c, fd);
		if(strcmp(string, "int") == 0){
			return INT;
		}else if(strcmp(string, "char") == 0){
			return CHAR;
		}else if(strcmp(string, "if") == 0){
			return IF;
		}else if(strcmp(string, "break") == 0){
			return BREAK;
		}else if(strcmp(string, "else") == 0){
			return ELSE;
		}else if(strcmp(string, "read") == 0){
			return READ;
		}else if(strcmp(string, "return") == 0){
			return RETURN;
		}else if(strcmp(string, "while") == 0){
			return WHILE;
		}else if(strcmp(string, "write") == 0){
			return WRITE;
		}else if(strcmp(string, "writeln") == 0){
			return WRITELN;
		}else{
			//This hashing algorithm was developed by Dan Bernstein
			//www.cse.yorku.ca/~oz/hash.html (this link was sometimes down for me)
			unsigned long hash = 5381;
			char c;
			while(c = *string++){
				hash = ((hash << 5) + hash) + c;
			}
			tokenval = hash;	//Placeholder value until we have a symbol table
			return ID;
		}
	}
}

tokenT C(FILE *fd, char *string){
	char c = getc(fd);

	if(c == '/'){
		char new_c = getc(fd);
		if(new_c == '/'){
			single_line_comment(fd);
		}else if(new_c == '*'){
			multi_line_comment(fd);
		}else{
			ungetc(new_c, fd);
		}
	}

	if(isdigit(c)){
		char temp_string[2] = {c, '\0'};
		strcat(string, temp_string);
		return C(fd, string);
	}else{
		ungetc(c, fd);
		tokenval = atoi(string);
		return NUM;
	}
}

tokenT D(FILE *fd){
	char c = getc(fd);

	if(c == '/'){
		char new_c = getc(fd);
		if(new_c == '/'){
			single_line_comment(fd);
		}else if(new_c == '*'){
			multi_line_comment(fd);
		}else{
			ungetc(new_c, fd);
		}
	}
	
	if(isspace(c)){
		return D(fd);
	}

	if(isalpha(c) || c == '\\'){
		if(c == '\\'){
			getc(fd);
			return M(fd, c, 1);
		}else{
			return M(fd, c, 0);
		}
	}else{
		return handle_error(c);
	}
}

tokenT E(FILE *fd, char old_c){
	char c = getc(fd);

	if(c == '/'){
		char new_c = getc(fd);
		if(new_c == '/'){
			single_line_comment(fd);
		}else if(new_c == '*'){
			multi_line_comment(fd);
		}else{
			ungetc(new_c, fd);
		}
	}
	
	if(isspace(c)){
		return E(fd, old_c);
	}

	if(c == '='){
		switch(old_c){
			case '<':
				return LE;
			case '!':
				return NE;
			case '>':
				return GE;
		}
	}else{
		ungetc(c, fd);
		switch(old_c){
			case '<':
				return LT;
			case '!':
				return NOT;
			case '>':
				return GT;
		}
	}
}

tokenT F(FILE *fd){
	char c = getc(fd);

	if(c == '/'){
		char new_c = getc(fd);
		if(new_c == '/'){
			single_line_comment(fd);
		}else if(new_c == '*'){
			multi_line_comment(fd);
		}else{
			ungetc(new_c, fd);
		}
	}
	
	if(isspace(c)){
		return F(fd);
	}

	if(c == '|'){
		return OR;
	}else{
		return handle_error(c);
	}
}

tokenT G(FILE *fd){
	char c = getc(fd);

	if(c == '/'){
		char new_c = getc(fd);
		if(new_c == '/'){
			single_line_comment(fd);
		}else if(new_c == '*'){
			multi_line_comment(fd);
		}else{
			ungetc(new_c, fd);
		}
	}
	
	if(isspace(c)){
		return G(fd);
	}

	if(c == '&'){
		return AND;
	}else{
		return handle_error(c);
	}
}

tokenT H(FILE *fd, char old_c){
	switch(old_c){
		case '-':
			return MINUS;
		case '+':
			return PLUS;
		case '/':
			return DIV;
		case '*':
			return MULT;
	}
}

tokenT I(FILE *fd, char old_c){
	switch(old_c){
		case '[':
			return LBRACK;
		case ']':	
			return RBRACK;
		case '{':	
			return LBRACE;
		case '}':	
			return RBRACE;
		case '(':	
			return LPAREN;
		case ')':	
			return RPAREN;
		case ',':	
			return COMMA;
		case ';':	
			return SEMI;
	}
}

tokenT A(FILE *fd){
	char c = getc(fd);

	int comment_started = 0;		//True if this '/' starts a comment

	if(c == '/'){
		char new_c = getc(fd);
		if(new_c == '/'){
			comment_started = 1;
			single_line_comment(fd);
			c = getc(fd);
		}else if(new_c == '*'){
			comment_started = 1;
			multi_line_comment(fd);
			c = getc(fd);
		}else{
			ungetc(new_c, fd);
			return DIV;
		}
	}
	
	if(isspace(c)){
		return A(fd);
	}

	if(isalpha(c) || c == '_'){
		char string[MAXLEXSIZE];
		string[0] = c;
		string[1] = '\0';
		return B(fd, string);
	}

	if(isdigit(c)){
		char string[MAXLEXSIZE];
		string[0] = c;
		string[1] = '\0';
		return C(fd, string);
	}

	switch(c){
		case '\'':
			return D(fd);
		case '<':
			return E(fd, c);
		case '!':
			return E(fd, c);
		case '>':
			return E(fd, c);
		case '|':
			return F(fd);
		case '&':
			return G(fd);
		case '-':
			return H(fd, c);
		case '+':
			return H(fd, c);
		case '*':
			return H(fd, c);
		case '/':
			return H(fd, c);
		case '[':
			return I(fd, c);
		case ']':
			return I(fd, c);
		case '{':
			return I(fd, c);
		case '}':
			return I(fd, c);
		case '(':
			return I(fd, c);
		case ')':
			return I(fd, c);
		case ',':
			return I(fd, c);
		case ';':
			return I(fd, c);
		case '=':
			return O(fd);
		default:
			return handle_error(c);
	}
}

/***************************************************************************/
/* 
 *  Main lexer routine:  returns the next token in the input 
 *
 *  param fd: file pointer for reading input file (source C-- program)
 *            TODO: you may want to add more parameters
 *
 *  returns: the next token, or 
 *           DONE if there are no more tokens, or
 *           LEXERROR if there is a token parsing error 
 */
int lexan(FILE *fd) {
  return A(fd);
}
/***************************************************************************/
// A function for demonstrating that functions should be declared static
// if they are to be used only in the file in which they are defined.
// Static limits the scope to only this .c file
static void print_lineno() {
  
  printf("line no = %d\n", src_lineno);

}