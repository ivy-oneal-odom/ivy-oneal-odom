#include "lexer.h"
#include "parser.h"
//
// generates the lexer's output
//   t: the token
//   tval: token value
//
void lexer_emit(int t, int tval) {
  switch(t) {
    case IF:
      printf("IF\n"); 
      break;
    case NUM:
      printf("NUM.%d\n", tval); 
      break;
    case STARTTOKEN:
      printf("STARTTOKEN\n"); 
      break;
    case INT:
      printf("INT\n"); 
      break;
    case CHAR:
      printf("CHAR\n"); 
      break;
    case ID:
      printf("ID.%d\n", tval); 
      break;
    case AND:
      printf("AND\n"); 
      break;
    case ASSIGN:
      printf("ASSIGN\n"); 
      break;
    case BREAK:
      printf("BREAK\n");  
      break;
    case COMMA:
      printf("COMMA\n"); 
      break;
    case DIV:
      printf("DIV\n"); 
      break;
    case ELSE:
      printf("ELSE\n"); 
      break;
    case EQ:
      printf("EQ\n"); 
      break;
    case GE:
      printf("GE\n"); 
      break;
    case GT:
      printf("GT\n"); 
      break;
    case LBRACE:
      printf("LBRACE\n"); 
      break;
    case LBRACK:
      printf("LBRACK\n"); 
      break;
    case LE:
      printf("LE\n"); 
      break;
    case LPAREN:
      printf("LPAREN\n");  
      break;
    case LT:
      printf("LT\n"); 
      break;
    case MINUS:
    // case MIN:    //This is for debugging Emilia's Code
      printf("MINUS\n"); 
      break;
    case MULT:
      printf("MULT\n"); 
      break;
    case NE:
      printf("NE\n"); 
      break;
    case NOT:
      printf("NOT\n"); 
      break;
    case OR:
      printf("OR\n"); 
      break;
    case PLUS:
    // case SUM:    //This is for debugging Emilia's Code
      printf("PLUS\n"); 
      break;
    case RBRACE:
      printf("RBRACE\n"); 
      break;
    case RBRACK:
      printf("RBRACK\n"); 
      break;
    case READ:
      printf("READ\n"); 
      break;
    case RETURN:
      printf("RETURN\n"); 
      break;
    case RPAREN:
      printf("RPAREN\n"); 
      break;
    case SEMI:
      printf("SEMI\n"); 
      break;
    case WHILE:
      printf("WHILE\n"); 
      break;
    case WRITE:
      printf("WRITE\n"); 
      break;
    case WRITELN:
      printf("WRITELN\n"); 
      break;
    case DONE:
      printf("DONE\n"); 
      break;
    case ENDTOKEN:
      printf("ENDTOKEN\n"); 
      break;
    case LEXERROR:
      printf("LEXERROR\n"); 
      break;
    case FUNC_DEC_LIST:
      printf("FDL\n");
      break;
    case PARAM_DEC_LIST:
      printf("PDL\n");
      break;
    case VAR_DEC_LIST:
      printf("VDL\n");
      break;
    case BLOCK_DEC_LIST:
      printf("BLOCK\n");
      break;
    case STMT_DEC_LIST:
      printf("STMT\n");
      break;
    case EXPR_DEC_LIST:
      printf("EXPR\n");
      break;
    case ROOT:
      printf("ROOT\n");
      break;
    default:
      printf("unknown token %c\n", tval); 
      break;
  }
}
