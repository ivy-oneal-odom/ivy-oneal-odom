/*
 *  Main function for C-- compiler
 */
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include "codegen.h"
#include "parser.h"
#include "lexer.h"
#include "ast.h"


void print_my_ast_node(ast_info *t);

int main(int argc, char *argv[]) {

  FILE *in = 0, *out = 0;

  if(argc != 3) { 
    printf("usage: ivycc  filename.c--  filename.mips\n");
    exit(1);
  }
  if(!(in = fopen(argv[1], "rw")) ) {
    perror("no such file\n");
    exit(1);
  }
  if(!(out = fopen(argv[2], "w")) ) {
    perror("opening output file failed\n");
    exit(1);
  }

  // TODO: these calls will need to be fixed to match the prototypes in
  //       your compiler
  //
  // init_symtab(); ...   // call any initialization routines here
  parse(in);   // call your main parse routine
  // printf("**********************************************\n");
  // print_ast(ast_tree, print_my_ast_node);    //For debugging purposes
  // printf("**********************************************\n");
  codegen();   // call your main code generation routine to fill codetable 
  generate_code_from_codetable(out);   // write MIPS code from codetable to
                                       // output file
  fclose(in);
  fclose(out);

  exit(0);     
}

static char *t_strings[] = {"start",
                            "int",
                            "char",
                            "if",
                            "NUM",
                            "ID",
                            "&&",
                            "=",
                            "break",
                            ",",
                            "/",
                            "else",
                            "==",
                            ">=",
                            ">",
                            "{",
                            "[",
                            "<=",
                            "(",
                            "<",
                            "-",
                            "*",
                            "!=",
                            "!",
                            "||",
                            "+",
                            "}",
                            "]",
                            "read",
                            "return",
                            ")",
                            ";",
                            "while",
                            "write",
                            "writeln",
                            "DONE"
                          };

static char *non_term_strings[] = {"root", "funcdec", "vardec", "paramdec", "block", "statement", "expression"};

void print_my_ast_node(ast_info *t) {
  if(t != NULL) {
    if((t->token >= STARTTOKEN) && (t->token <= ENDTOKEN)) {
      printf("%s", t_strings[(t->token - STARTTOKEN)]);
      if(t->token == NUM || t-> token == ID){
        printf(":%d", t->value);
      }

    }
    else if ((t->token == NONTERMINAL)) {
       if((t->grammar_symbol >= START_AST_SYM) 
           && (t->grammar_symbol <= END_AST_SYM)) 
       {
           printf("%s", non_term_strings[(t->grammar_symbol - START_AST_SYM)]);
       }
       else {
           printf("unknown grammar symbol %d", t->grammar_symbol);
       }
    }
    else {
      printf("unknown token %d", t->token);
    }
  }
  else {
    printf("NULL token\n");
  }
}