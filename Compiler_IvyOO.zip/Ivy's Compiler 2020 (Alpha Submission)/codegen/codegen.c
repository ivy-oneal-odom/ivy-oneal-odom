// functions for generating MIPS code given an AST of a C-- program
// from the parser

// TODO: add more includes files here as necessary
#include <stdio.h>
#include <assert.h>
#include "symtab.h"
#include "parser.h"
#include "codegen.h"
#include "ast.h"
#include "lexer.h"

int counter = 0;		//This counter will increment each time we make a new function, etc. to keep names unique

int prev = 0;			//The index of where we left off

Stack block_stack_obj;					//Used to keep track of what block/function we're currently in
Stack *block_stack = &block_stack_obj;	//Helpful for break and return
Stack func_stack_obj;					
Stack *func_stack = &func_stack_obj;

int scope;			//A counter used to tell what scope we're in
						//Equals the index of the item on the stack to reference

//I had some difficulties with pointers and addresses, but this works
Table table_obj;
Table *table = &table_obj;


// this function will be called after your parse function
// depending on how you are storing the AST (a global or a return
// value from parse, you may need to add some parameters to this function
void codegen() {

	printf("GENERATING CODE\n");
	scope = 0;
	on_ast_node(ast_tree.root);
}

void on_ast_node(ast_node *n){
	int node_value = get_node_value(n->symbol);

	unsigned long hash;
	char tmp[MAX_LINE_LEN];
	char var_label[MAX_LINE_LEN];
	char inst[MAX_LINE_LEN];
	switch(node_value){
		case ROOT:
			prev = ct_init(0);
			for(int i = 0; i < n->num_children; i++){
				on_ast_node(n->childlist[i]);
			}
			break;
		case BLOCK_DEC_LIST:
			scope++;
			prev = ct_comment(prev, "BLOCK START");
			prev = ct_store_regs(prev);

			int old_block_num = get_top(block_stack);
			push(block_stack, old_block_num + 1);

			for(int i = 0; i < n->num_children; i++){
				on_ast_node(n->childlist[i]);
			}

			prev = ct_load_regs(prev);
			sprintf(inst, "BLOCK_END%d:", old_block_num + 1);
			prev = ct_inst(prev, inst);
			prev = ct_comment(prev, "BLOCK END");
			scope--;
			break;
		case FUNC_DEC_LIST:
			scope++;
			prev = ct_comment(prev, "FUNC START");
			int hash = n->childlist[1]->symbol->value;
			char inst[MAX_LINE_LEN];
			//Make sure anyone happening upon this function skips over it
			push(func_stack, hash);
			if(hash != 2090499946){		//The hash of "main"
				sprintf(inst, "j FUNC_END%d", hash);
				prev = ct_inst(prev, inst);


				sprintf(inst, "FUNC_%d:", hash);
			}else{
				strcpy(inst, "main:");
			}

			prev = ct_inst(prev, inst);

			prev = ct_store_regs(prev);

			//Store Params
			int num_params = n->childlist[2]->num_children / 2;

			for(int i = 0; i < num_params; i++){
				add_address_to_table(table, n->childlist[2]->childlist[i*2 + 1]->symbol->value, counter);

				strcpy(inst, ".data");
				prev = ct_inst(prev, inst);

				sprintf(inst, "variable_%d_scope%d:", counter, scope + 1);
				prev = ct_inst(prev, inst);

				prev = ct_inst(prev, ".word 0");
				prev = ct_inst(prev, ".text");

				sprintf(inst, "sw $a%d, variable_%d_scope%d", i, counter, scope + 1);
				prev = ct_inst(prev, inst);

				counter++;
			}

			//Function Body

			on_ast_node(n->childlist[3]);


			//Wrap Up Function
			prev = ct_load_regs(prev);
			sprintf(inst, "FUNC_END%d:", hash);
			prev = ct_inst(prev, inst);
			prev = ct_inst(prev, "j $ra");
			prev = ct_comment(prev, "FUNC END");
			scope--;
			break;
		case VAR_DEC_LIST:
			hash = n->childlist[1]->symbol->value;
			add_address_to_table(table, hash, counter);

			//Add the storage space to the mips code
			char tmp[MAX_LINE_LEN];
			sprintf(tmp, "%d", counter++);
			char var_label[MAX_LINE_LEN];
			strcpy(var_label, "variable_");
			strcat(var_label, tmp);
			strcpy(tmp, "");
			sprintf(tmp, "%d", scope);
			strcat(var_label, "_scope");
			strcat(var_label, tmp);
			strcat(var_label, ":");
			prev = ct_inst(prev, ".data");
			prev = ct_inst(prev, var_label);
			prev = ct_inst(prev, ".word 0");
			prev = ct_inst(prev, ".text");
			break;
		case STMT_DEC_LIST:
			prev = ct_comment(prev, "STMT START");
			prev = ct_store_regs(prev);


			for(int i = 0; i < n->num_children; i++){
				int stmt_type = get_node_value(n->childlist[i]->symbol);


				char tmp[MAX_LINE_LEN];
				char tmp2[MAX_LINE_LEN];
				char if_label[MAX_LINE_LEN];
				char else_label[MAX_LINE_LEN];
				char done_label[MAX_LINE_LEN];
				char stmt_label[MAX_LINE_LEN];
				char check_label[MAX_LINE_LEN];
				int has_else;
				switch(stmt_type){
					case IF:
						has_else = (n->childlist[i]->num_children == 3) ? 1 : 0;
//Expression handler
						//Eval expression at n-childlist[i + 1] into $t0;
						on_ast_node(n->childlist[i]->childlist[0]);
						prev = ct_inst(prev, "move $t0, $v0");

						//Setup branch
						sprintf(tmp, "%d", counter++);
						strcpy(if_label, "IF");
						strcat(if_label, tmp);
						strcpy(else_label, "ELSE");
						strcat(else_label, tmp);
						strcpy(done_label, "IF_DONE");
						strcat(done_label, tmp);

						strcpy(tmp, "beq $zero, $t0, ");
						if(has_else){
							strcat(tmp, else_label);
						}else{
							strcat(tmp, done_label);
						}
						prev = ct_inst(prev, tmp);
						strcpy(tmp, "j ");
						strcat(tmp, if_label);
						prev = ct_inst(prev, tmp);
//If stmt handler
						strcpy(tmp, if_label);
						strcat(tmp, ":");
						prev = ct_inst(prev, tmp);

						//Do the stmt
						on_ast_node(n->childlist[i]->childlist[1]);

						strcpy(tmp, "j ");
						strcat(tmp, done_label);
						prev = ct_inst(prev, tmp);

//Else stmt handler
						if(has_else){
							strcpy(tmp, else_label);
							strcat(tmp, ":");
							prev = ct_inst(prev, tmp);

							//Do the stmt
							on_ast_node(n->childlist[i]->childlist[2]);

							strcpy(tmp, "j ");
							strcat(tmp, done_label);
							prev = ct_inst(prev, tmp);
						}
//Done handler
						strcpy(tmp, done_label);
						strcat(tmp, ":");
						prev = ct_inst(prev, tmp);
						break;
					case WHILE:
						sprintf(tmp, "%d", counter++);
//Expression handler
						strcpy(check_label, "WHILE_CHECK");
						strcat(check_label, tmp);


						strcpy(tmp2, check_label);
						strcat(tmp2, ":");
						prev = ct_inst(prev, tmp2);

						//Eval expression at n-childlist[i + 1] into $t0;
						on_ast_node(n->childlist[i]->childlist[0]);
						prev = ct_inst(prev, "move $t0, $v0");

						//Setup branch
						strcpy(stmt_label, "WHILE_STMT");
						strcat(stmt_label, tmp);
						strcpy(done_label, "WHILE_DONE");
						strcat(done_label, tmp);


						strcpy(tmp, "beq $zero, $t0, ");
						strcat(tmp, done_label);
						prev = ct_inst(prev, tmp);

						strcpy(tmp, "j ");
						strcat(tmp, stmt_label);
						prev = ct_inst(prev, tmp);
//While stmt handler
						strcpy(tmp, stmt_label);
						strcat(tmp, ":");
						prev = ct_inst(prev, tmp);

						//Do the stmt
						on_ast_node(n->childlist[i]->childlist[1]);

						strcpy(tmp, "j ");
						strcat(tmp, check_label);
						prev = ct_inst(prev, tmp);
//Done handler
						strcpy(tmp, done_label);
						strcat(tmp, ":");
						prev = ct_inst(prev, tmp);
						break;
					default:
						on_ast_node(n->childlist[i]);
						break;
				}
			}

			prev = ct_load_regs(prev);
			prev = ct_comment(prev, "STMT END");

			break;
		case EXPR_DEC_LIST:
			prev = ct_comment(prev, "EXPR START");
			prev = ct_store_regs(prev);

			if(n->num_children == 2){		//This expression has an operation, lhs, rhs, etc.
				char tmp[MAX_LINE_LEN];
				char var_label[MAX_LINE_LEN];
				char func_label[MAX_LINE_LEN];
				char inst[MAX_LINE_LEN];

				//Store LHS in $t0 THIS WILL NEED TO CHANGE ONCE WE ADD FUNCTION CALLS
				int lhs = get_node_value(n->childlist[0]->symbol);
				switch(lhs){
					case NUM:
						prev = ct_li(prev, "$t0", n->childlist[0]->symbol->value);
						break;
					case ID:
						hash = n->childlist[0]->symbol->value;

						if(get_address_from_table(table, hash) != -1){
							//For variables
							sprintf(tmp, "%d", get_address_from_table(table, hash));
							strcpy(var_label, "variable_");
							strcat(var_label, tmp);
							strcpy(tmp, "");
							sprintf(tmp, "%d", scope);
							strcat(var_label, "_scope");
							strcat(var_label, tmp);

							strcpy(inst, "lw $t0 ");
							strcat(inst, var_label);

							prev = ct_inst(prev, inst);
						}
						break;
					case EXPR_DEC_LIST:
						on_ast_node(n->childlist[0]);
						prev = ct_inst(prev, "move $t0, $v0");
						break;
					default:
						perror("Error getting right hand side of expression");
						break;
				}
				
				int rhs = -1;
				if(n->childlist[1]->num_children != 0){
					//Store RHS in $t1
					rhs = get_node_value(n->childlist[1]->childlist[0]->symbol);
					switch(rhs){
						case NUM:
							prev = ct_li(prev, "$t1", n->childlist[1]->childlist[0]->symbol->value);
							break;
						case ID:
							hash = n->childlist[0]->symbol->value;

							if(get_address_from_table(table, hash) != -1){
								//For variables
								sprintf(tmp, "%d", get_address_from_table(table, hash));
								strcpy(var_label, "variable_");
								strcat(var_label, tmp);
								strcpy(tmp, "");
								sprintf(tmp, "%d", scope);
								strcat(var_label, "_scope");
								strcat(var_label, tmp);

								strcpy(inst, "lw $t0 ");
								strcat(inst, var_label);

								prev = ct_inst(prev, inst);
							}
							break;
						case EXPR_DEC_LIST:
							on_ast_node(n->childlist[1]->childlist[0]);
							prev = ct_inst(prev, "move $t1, $v0");
							break;
						default:
							perror("Error getting right hand side of expression");
							break;
					}
				}

				//Store expression results in $v0
				int operation = get_node_value(n->childlist[1]->symbol);	//The second child is always the operation type
				
				switch(operation){
					case PLUS:
						prev = ct_inst(prev, "add $v0, $t0, $t1");
						break;
					case MINUS:
						prev = ct_inst(prev, "sub $v0, $t0, $t1");
						break;
					case MULT:
						prev = ct_inst(prev, "mul $v0, $t0, $t1");
						break;
					case DIV:
						prev = ct_inst(prev, "div $v0, $t0, $t1");
						break;
					case AND:
						prev = ct_inst(prev, "and $v0, $t0, $t1");
						break;
					case OR:
						prev = ct_inst(prev, "or $v0, $t0, $t1");
						break;
					case GT:
						prev = ct_inst(prev, "sub $t2, $t0, $t1");	//Get difference
						//If $t2 is positive, then return 1
						prev = ct_inst(prev, "slt $v0, $zero, $t2");
						break;
					case GE:
						prev = ct_inst(prev, "slt $t2, $t0, $t1");	//$t2 is 1 if LT
						prev = ct_inst(prev, "li $v0, 1");			//Assume true
						prev = ct_inst(prev, "movn $v0, $zero, $t2");
						break;
					case LT:
						prev = ct_inst(prev, "slt $v0, $t0, $t1");
						break;
					case LE:
						prev = ct_inst(prev, "sub $t2, $t0, $t1");	//Get difference
						//If $t2 is positive, then return 0
						prev = ct_inst(prev, "slti $v0, $t2, 1");
						break;
					case NOT:break;
					case EQ:
						prev = ct_inst(prev, "sub $t2, $t0, $t1");	//Get difference
						prev = ct_inst(prev, "li $v0, 1");			//Assume true
						prev = ct_inst(prev, "movn $v0, $zero, $t2");//If difference, false
						break;
					case NE:
						prev = ct_inst(prev, "sub $t2, $t0, $t1");	//Get difference
						prev = ct_inst(prev, "li $v0, 1");			//Assume false
						prev = ct_inst(prev, "movz $v0, $zero, $t2");//If difference, true
						break;
					case ASSIGN:
						hash = n->childlist[0]->symbol->value;

						sprintf(tmp, "%d", get_address_from_table(table, hash));
						strcpy(var_label, "variable_");
						strcat(var_label, tmp);
						strcpy(tmp, "");
						sprintf(tmp, "%d", scope);
						strcat(var_label, "_scope");
						strcat(var_label, tmp);

						strcpy(inst, "sw $t1 ");
						strcat(inst, var_label);


						prev = ct_inst(prev, inst);

						break;
					case LPAREN:	//This denotes a function call to $t0
						{
							hash = n->childlist[0]->symbol->value;
							//Setup params then jal to $t0
							int num_params = n->childlist[1]->num_children;
							num_params = (num_params <= 4) ? num_params : 4;


							for(int i = 0; i < num_params; i++){
								//For each param, eval the expr and move $v0 to $ai
								on_ast_node(n->childlist[1]->childlist[i]);

								sprintf(tmp, "%d", i);
								strcpy(inst, "move $a");
								strcat(inst, tmp);
								strcat(inst, ", $v0");


								prev = ct_inst(prev, inst);
							}

							sprintf(func_label, "FUNC_%d", hash);

							strcpy(inst, "jal ");
							strcat(inst, func_label);


							prev = ct_store_regs(prev);
							prev = ct_inst(prev, inst);
							prev = ct_load_regs(prev);
						}

						break;
					default:
						perror("Error getting operation of expression");
						break;
				}
			}else if(n->num_children == 1){//This is just one thing
				if(get_node_value(n->childlist[0]->symbol) == EXPR_DEC_LIST){
					on_ast_node(n->childlist[0]);	
				}else if(get_node_value(n->childlist[0]->symbol) == NUM){
					prev = ct_li(prev, "$v0", n->childlist[0]->symbol->value);
				}else if(get_node_value(n->childlist[0]->symbol) == ID){
					hash = n->childlist[0]->symbol->value;

					if(get_address_from_table(table, hash) == -1){
						perror("Error, bad variable or scope");
					}else{
						sprintf(tmp, "%d", get_address_from_table(table, hash));
						strcpy(var_label, "variable_");
						strcat(var_label, tmp);
						strcpy(tmp, "");
						sprintf(tmp, "%d", scope);
						strcat(var_label, "_scope");
						strcat(var_label, tmp);

						strcpy(inst, "lw $v0 ");
						strcat(inst, var_label);


						prev = ct_inst(prev, inst);
					}
				}else if(get_node_value(n->childlist[0]->symbol) == NOT){
					int lhs = get_node_value(n->childlist[0]->childlist[0]->symbol);
					switch(lhs){
						case NUM:
							prev = ct_li(prev, "$t0", n->childlist[0]->childlist[0]->symbol->value);
							break;
						case ID:
							hash = n->childlist[0]->symbol->value;

							if(get_address_from_table(table, hash) != -1){
								//For variables
								sprintf(tmp, "%d", get_address_from_table(table, hash));
								strcpy(var_label, "variable_");
								strcat(var_label, tmp);
								strcpy(tmp, "");
								sprintf(tmp, "%d", scope);
								strcat(var_label, "_scope");
								strcat(var_label, tmp);

								strcpy(inst, "lw $t0 ");
								strcat(inst, var_label);

								prev = ct_inst(prev, inst);
							}
							break;
						case EXPR_DEC_LIST:
							on_ast_node(n->childlist[0]);
							prev = ct_inst(prev, "move $t0, $v0");
							break;
						default:
							perror("Error getting right hand side of expression");
							break;
					}

					//If $t0 == 0, return 1, otherwise return 0
					prev = ct_inst(prev, "li $v0, 1");			//Assume true
					prev = ct_inst(prev, "movn $v0, $zero, $t0");//If difference, false	
				}else if(get_node_value(n->childlist[0]->symbol) == MINUS){
					int lhs = get_node_value(n->childlist[0]->childlist[0]->symbol);
					
					switch(lhs){
						case NUM:
							prev = ct_li(prev, "$t0", n->childlist[0]->childlist[0]->symbol->value);
							break;
						case ID:
							hash = n->childlist[0]->symbol->value;

							if(get_address_from_table(table, hash) != -1){
								//For variables
								sprintf(tmp, "%d", get_address_from_table(table, hash));
								strcpy(var_label, "variable_");
								strcat(var_label, tmp);
								strcpy(tmp, "");
								sprintf(tmp, "%d", scope);
								strcat(var_label, "_scope");
								strcat(var_label, tmp);

								strcpy(inst, "lw $t0 ");
								strcat(inst, var_label);

								prev = ct_inst(prev, inst);
							}
							break;
						case EXPR_DEC_LIST:
							on_ast_node(n->childlist[0]);
							prev = ct_inst(prev, "move $t0, $v0");
							break;
						default:
							perror("Error getting right hand side of expression");
							break;
					}

					prev = ct_li(prev, "$t1", -1);
					prev = ct_inst(prev, "mul $v0, $t0, $t1");
				}
			}else{
				//If the expression is empty, return 0
				prev = ct_inst("li $v0, 0");
			}



			prev = ct_load_regs(prev);
			prev = ct_comment(prev, "EXPR END");
			break;
		case WRITE:
			prev = ct_comment(prev, "WRITE START");
			prev = ct_store_regs(prev);

			//Calculate Write Contents using $v0 for expression results
			for(int i = 0; i < n->num_children; i++){
				on_ast_node(n->childlist[i]);
			}

			//Print Write Contents
			prev = ct_inst(prev, "move $a0, $v0");
			prev = ct_inst(prev, "li $v0, 1");
			prev = ct_inst(prev, "syscall");

			prev = ct_load_regs(prev);
			prev = ct_comment(prev, "WRITE END");
			break;
		case WRITELN:
			prev = ct_comment(prev, "WRITELN START");
			prev = ct_store_regs(prev);

			//Print Write Contents
			prev = ct_inst(prev, "la $a0, _new_line_");
			prev = ct_inst(prev, "li $v0, 4");
			prev = ct_inst(prev, "syscall");

			prev = ct_load_regs(prev);
			prev = ct_comment(prev, "WRITELN END");
			break;
		case READ:
			prev = ct_comment(prev, "READ START");
			prev = ct_store_regs(prev);


			//Store user int in $v0
			prev = ct_inst(prev, "li $v0, 5");
			prev = ct_inst(prev, "syscall");

			hash = n->childlist[0]->symbol->value;

			if(get_address_from_table(table, hash) != -1){
				//For variables
				sprintf(tmp, "%d", get_address_from_table(table, hash));
				strcpy(var_label, "variable_");
				strcat(var_label, tmp);
				strcpy(tmp, "");
				sprintf(tmp, "%d", scope);
				strcat(var_label, "_scope");
				strcat(var_label, tmp);

				strcpy(inst, "sw $v0 ");
				strcat(inst, var_label);

				prev = ct_inst(prev, inst);
			}


			prev = ct_load_regs(prev);
			prev = ct_comment(prev, "READ START");
			break;
		case RETURN:
			on_ast_node(n->childlist[0]);	//Eval the expr
			sprintf(inst, "j FUNC_END%d", pop(func_stack));
			break;
		case BREAK:
			break;
		default:
			return;
			break;		//unnecessary? yes. comforting? also yes
	}
}

int get_node_value(ast_info *t){
	if(t != NULL) {
		//The node is a terminal
		if((t->token >= STARTTOKEN) && (t->token <= ENDTOKEN)) {
			return t->token;

		//The node is a nonterminal
		}else if ((t->token == NONTERMINAL)) {
			if((t->grammar_symbol >= START_AST_SYM) && (t->grammar_symbol <= END_AST_SYM)) {
				return t->grammar_symbol;
			}else {
				printf("unknown grammar symbol %d", t->grammar_symbol);
				perror("^^^^\n");
			}
		}else {
		printf("unknown token %d", t->token);
		perror("^^^^\n");
		}
	}else {
		perror("NULL token\n");
	}
}