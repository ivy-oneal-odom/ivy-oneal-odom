// functions to add, remove, modify entries in code table and
// to write codetable to MIPS output file

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "codegen.h"
#include "lexer.h"
#include "parser.h"

char code_table[MAX_LINES][MAX_LINE_LEN];

int ct_comment(int offset, char *comment){
	char tmp[MAX_LINE_LEN];
	strcpy(tmp, "#");
	strcat(tmp, comment);
	strcpy(code_table[offset], tmp);
	
	return offset + 1;
}

int ct_init(int offset){
	strcpy(code_table[offset], ".data");
	strcpy(code_table[offset + 1], "_new_line_:");
	strcpy(code_table[offset + 2], ".asciiz \"\\n\"");
	strcpy(code_table[offset + 3], ".text");
	strcpy(code_table[offset + 4], ".globl main");
	return offset + 5;
}

int ct_inst(int offset, char *instruction){
	strcpy(code_table[offset], instruction);

	return offset + 1;
}

int ct_li(int offset, char *reg, int val){
	char tmp[MAX_LINE_LEN];
	sprintf(tmp, "%d", val);
	char inst[MAX_LINE_LEN];
	strcpy(inst, "li ");
	strcat(inst, reg);
	strcat(inst, ", ");
	strcat(inst, tmp);

	strcpy(code_table[offset], inst);

	return offset + 1;
}


//Saves all registers (overkill, but works)
int ct_store_regs(int offset){
	strcpy(code_table[offset], "#Save registers");
	strcpy(code_table[offset + 1], "addi $sp, $sp, -60");
	strcpy(code_table[offset + 2], "sw $ra, 0($sp)");
	strcpy(code_table[offset + 3], "sw $a0, 4($sp)");
	strcpy(code_table[offset + 4], "sw $a1, 8($sp)");
	strcpy(code_table[offset + 5], "sw $a2, 12($sp)");
	strcpy(code_table[offset + 6], "sw $a3, 16($sp)");
	strcpy(code_table[offset + 7], "sw $t0, 20($sp)");
	strcpy(code_table[offset + 8], "sw $t1, 24($sp)");
	strcpy(code_table[offset + 9], "sw $t2, 28($sp)");
	strcpy(code_table[offset + 10], "sw $t3, 32($sp)");
	strcpy(code_table[offset + 11], "sw $t4, 36($sp)");
	strcpy(code_table[offset + 12], "sw $t5, 40($sp)");
	strcpy(code_table[offset + 13], "sw $t6, 44($sp)");
	strcpy(code_table[offset + 14], "sw $t7, 48($sp)");
	strcpy(code_table[offset + 15], "sw $t8, 52($sp)");
	strcpy(code_table[offset + 16], "sw $t9, 56($sp)");

	return offset + 17;
}

int ct_load_regs(int offset){
	strcpy(code_table[offset], "#Load registers");
	strcpy(code_table[offset + 1], "lw $ra, 0($sp)");
	strcpy(code_table[offset + 2], "lw $a0, 4($sp)");
	strcpy(code_table[offset + 3], "lw $a1, 8($sp)");
	strcpy(code_table[offset + 4], "lw $a2, 12($sp)");
	strcpy(code_table[offset + 5], "lw $a3, 16($sp)");
	strcpy(code_table[offset + 6], "lw $t0, 20($sp)");
	strcpy(code_table[offset + 7], "lw $t1, 24($sp)");
	strcpy(code_table[offset + 8], "lw $t2, 28($sp)");
	strcpy(code_table[offset + 9], "lw $t3, 32($sp)");
	strcpy(code_table[offset + 10], "lw $t4, 36($sp)");
	strcpy(code_table[offset + 11], "lw $t5, 40($sp)");
	strcpy(code_table[offset + 12], "lw $t6, 44($sp)");
	strcpy(code_table[offset + 13], "lw $t7, 48($sp)");
	strcpy(code_table[offset + 14], "lw $t8, 52($sp)");
	strcpy(code_table[offset + 15], "lw $t9, 56($sp)");
	strcpy(code_table[offset + 16], "addi $sp, $sp, 60");

	return offset + 17;
}


//Write the codetable to the file
void generate_code_from_codetable(FILE *out){
	int used_lines = 0;
	for(int i = 0; i < MAX_LINES; i++){
		if(strlen(code_table[i]) != 0){
			char *tmps = strcat(code_table[i], "\n");
			fputs(tmps, out);
			used_lines++;
		}
	}

	printf("\nAvailable Lines Remaining: %d (Increase MAX_LINES in codegen.h if this number ever becomes small)\n", MAX_LINES - used_lines);
}