//This symbol table is a table of stacks
#include "symtab.h"

//Adds a new item to the Stack
void push(Stack *stack, int address){
	stack->addresses[stack->top] = address;
	stack->top++;
}

//Returns the top address on the Stack
int get_top(Stack *stack){
	if(stack->top > 0){
		return stack->addresses[stack->top - 1];
	}else{
		return 0;
	}
}

//Removes and returns the top address on the Stack
int pop(Stack *stack){
	if(stack->top == 0){
		return -1;
	}


	int address = stack->addresses[stack->top - 1];
	stack->addresses[stack->top - 1] = 0;
	stack->top--;
	return address;
}

//Returns the index of a variable name in the Table (or -1 if it doesn't exist yet);
int get_index_in_table(Table *table, unsigned long search_hash){
	for(int i = 0; i < table->top; i++){
		Stack *stack = &(table->stacks[i]);
		if(stack->hash == search_hash){
			return i;
		}
	}

	return -1;
}

//Adds a new variable to the table or adds the new scope to an existing variable stack
void add_address_to_table(Table *table, unsigned long new_hash, int address){
	int index = get_index_in_table(table, new_hash);

	if(index == -1){
		//Add a new entry to the table
		push(&(table->stacks[table->top]), address);
		Stack *stack = &(table->stacks[table->top]);
		stack->hash = new_hash;
		table->top++;
	}else{
		//Update an existing entry
		push(&(table->stacks[index]), address);
	}
}

//Gets the top address of the given variable
int get_address_from_table(Table *table, unsigned long hash){
	int index = get_index_in_table(table, hash);

	if(index == -1){
		return -1;
	}else{
		return(get_top(&(table->stacks[index])));
	}
}

//Gets and removes the top address of the given variable
int pop_address_from_table(Table *table, unsigned long hash){
	int index = get_index_in_table(table, hash);

	if(index == -1){
		perror("No stack at that hash");
		return -1;
	}else{
		return(pop(&(table->stacks[index])));
	}
}