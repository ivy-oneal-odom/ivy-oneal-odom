/*
 * parser.c: A Recursive Descent Parser for C--
 *
 */
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "parser.h"
#include "lexer.h"
#include "ast.h"

// TODO: you may completely wipe out or change the contents of this file; it
//       is just an example of how to get started on the structure of the 
//       parser program.

static void program(FILE *fd, ast_node *parent);
static void parser_error(char *err_string);

int lookahead;  // stores next token returned by lexer
                // you may need to change its type to match your implementation
ast_node *prev; //Previous ast_node

ast ast_tree;   // the abstract syntax tree

int old_lookahead;

/**************************************************************************/
/*
 *  Main parser routine: parses the C-- program in input file pt'ed to by fd, 
 *                       calls the function corresponding to the start state,
 *                       checks to see that the last token is DONE,
 *                       prints a success msg if there were no parsing errors
 *  param fd: file pointer for input
 */
void parse(FILE *fd)  {

  ast_info *s;
  ast_node *n;

  // create the root AST node
  s = create_new_ast_node_info(NONTERMINAL, 0, ROOT, 0, 0);
  n = create_ast_node(s);
  if(init_ast(&ast_tree, n)) {
        parser_error("ERROR: bad AST\n");
  }

  // lookahead is a global variable holding the next token
  // you could also use a local variable and then pass it to program
  lookahead = lexan(fd);
  program(fd, ast_tree.root);

  // the last token should be DONE
  if (lookahead != DONE) {
    parser_error("expected end of file");   
  }
}
/**************************************************************************/
static void parser_error(char *err_string) {
  if(err_string) {
    printf("%s\n", err_string);
  }
  exit(1);
}  

//Makes a nonterminal node
ast_node *mknonterm(int token){
  ast_info *i = create_new_ast_node_info(NONTERMINAL, 0, token, 0, 0);
  ast_node *n = create_ast_node(i);
  prev = n;
  return n;
}

//Makes a terminal node
ast_node *mknode(int token){
  ast_info *i = create_new_ast_node_info(token, tokenval, 0, 0, 0);
  ast_node *n = create_ast_node(i);
  prev = n;
  return n;
}

//Set the lookahead to the next lexeme
void set_lookahead(FILE *fd){
  if(old_lookahead){
    lookahead = old_lookahead;
    old_lookahead = 0;
  }else{
    lookahead = lexan(fd);
  }
}

//Unget a lexeme, like using ungetc
void ungetl(){
  old_lookahead = lookahead;
}
/**************************************************************************/
/*
 *  this function corresponds to the start symbol in the LL(1) grammar
 *  when this function returns, the full AST tree with parent node "parent"
 *  will be constructed
 *         fd: the input stream
 *     parent: the parent ast node  (it should be a ROOT)
 */
static void program(FILE *fd, ast_node *parent) {

  printf("PARSING PROGRAM\n");

  ast_node *n;

  switch(lookahead){
    case INT:
      n = mknonterm(FUNC_DEC_LIST);
      add_child_node(parent, n);
      add_child_node(n, mknode(INT));
      set_lookahead(fd);
      add_child_node(n, mknode(ID));
      prog1(fd, n, parent);
      break;
    case CHAR:
      n = mknonterm(FUNC_DEC_LIST);
      add_child_node(parent, n);
      add_child_node(n, mknode(CHAR));
      set_lookahead(fd);
      add_child_node(n, mknode(ID));
      prog1(fd, n, parent);
      break;
    default:
      parser_error("Error in program");
      break;
  }
}

//*dparent (used here and elsewhere), let's a node get added as a child to its grandparent (double parent), instead of its parent
void prog1(FILE *fd, ast_node *parent, ast_node *dparent){
  set_lookahead(fd);
  switch(lookahead){
    case SEMI:
      add_child_node(parent, mknode(SEMI));
      program(fd, prev);
      break;
    case LBRACK:
      add_child_node(parent, mknode(LBRACK));
      set_lookahead(fd);
      add_child_node(parent, mknode(NUM));
      set_lookahead(fd);
      add_child_node(parent, mknode(RBRACK));
      program(fd, prev);
      break;
    default:
      ungetl();
      prog2(fd, parent, dparent);
      break;
  }
}


void prog2(FILE *fd, ast_node *parent, ast_node *dparent){
  set_lookahead(fd);
  switch(lookahead){
    case LPAREN:
      fdl1(fd, parent, dparent);
      break;
    default:
      parser_error("Error in prog2");
      break;
  }
}

void fdl1(FILE *fd, ast_node *parent, ast_node *dparent){
  ast_node *n = mknonterm(PARAM_DEC_LIST);
  add_child_node(parent, n);

  pdl(fd, n);
  set_lookahead(fd);

  ast_node *n2 = mknonterm(BLOCK_DEC_LIST);
  add_child_node(parent, n2);
  block(fd, n2);
  fdl(fd, dparent);
}

void fdl(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n;

  switch(lookahead){
    case INT:
      n = mknonterm(FUNC_DEC_LIST);
      add_child_node(parent, n);
      add_child_node(n, mknode(INT));
      set_lookahead(fd);
      add_child_node(n, mknode(ID));
      set_lookahead(fd);
      fdl1(fd, n, parent);
      break;
    case CHAR:
      n = mknonterm(FUNC_DEC_LIST);
      add_child_node(parent, n);
      add_child_node(n, mknode(CHAR));
      set_lookahead(fd);
      add_child_node(n, mknode(ID));
      set_lookahead(fd);
      fdl1(fd, n, parent);
      break;
  }
}

void vdl(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n;

  switch(lookahead){
    case INT:
      n = mknonterm(VAR_DEC_LIST);
      add_child_node(parent, n);
      add_child_node(n, mknode(INT));
      set_lookahead(fd);
      add_child_node(n, mknode(ID));
      vdl1(fd, n, parent);
      break;
    case CHAR:
      n = mknonterm(VAR_DEC_LIST);
      add_child_node(parent, n);
      add_child_node(n, mknode(CHAR));
      set_lookahead(fd);
      add_child_node(n, mknode(ID));
      vdl1(fd, n, parent);
      break;
    default:
      ungetl();
      break;
  }
}

void vdl1(FILE *fd, ast_node *parent, ast_node *dparent){
  set_lookahead(fd);

  switch(lookahead){
    case SEMI:
      vdl(fd, dparent);
      break;
    case LBRACK:
      add_child_node(parent, mknode(LBRACK));
      set_lookahead(fd);
      add_child_node(parent, mknode(NUM));
      set_lookahead(fd);
      add_child_node(parent, mknode(RBRACK));
      set_lookahead(fd);
      vdl(fd, dparent);
      break;
    default:
      parser_error("Error in vdl1");
      break;
  }
}

void pdl(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  switch(lookahead){
    case CHAR:
      add_child_node(parent, mknode(CHAR));
      set_lookahead(fd);
      add_child_node(parent, mknode(ID));
      pdl1(fd, parent);
      break;
    case INT:
      add_child_node(parent, mknode(INT));
      set_lookahead(fd);
      add_child_node(parent, mknode(ID));
      pdl1(fd, parent);
      break;
  }
}

void pdl1(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  switch(lookahead){
    case LBRACK:
      set_lookahead(fd);
      pdl2(fd, parent);
      break;
    default:
      ungetl();
      pdl2(fd, parent);
      break;
  }
}

void pdl2(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  switch(lookahead){
    case COMMA:
      pdl(fd, parent);
      break;
  }
}

void block(FILE *fd, ast_node *parent){
  vdl(fd, parent);
  stmtlist(fd, parent);
}

void stmtlist(FILE *fd, ast_node *parent){
  stmt(fd, parent);
  stmtlist1(fd, parent);
}

void stmtlist1(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  switch(lookahead){
    case RBRACE:
      break;
    case DONE:    //Is this ugly? yes. does it work? also yes. am I sorry? you bet.
      break;
    default:
      ungetl();
      stmtlist(fd, parent);
      break;
  }
}

void stmt(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n = mknonterm(STMT_DEC_LIST);
  add_child_node(parent, n);
  ast_node *s_node;
  switch(lookahead){
    case SEMI:
      break;
    case RETURN:
      add_child_node(n, mknode(RETURN));
      expr(fd, prev);
      set_lookahead(fd);
      break;
    case READ:
      s_node = mknode(READ);
      add_child_node(n, s_node);
      set_lookahead(fd);
      add_child_node(s_node, mknode(ID));
      break;
    case WRITE:
      add_child_node(n, mknode(WRITE));
      expr(fd, prev);
      set_lookahead(fd);
      break;
    case WRITELN:
      add_child_node(n, mknode(WRITELN));
      set_lookahead(fd);
      break;
    case BREAK:
      add_child_node(n, mknode(BREAK));
      set_lookahead(fd);
      break;
    case IF:
      s_node = mknode(IF);
      add_child_node(n, s_node);
      set_lookahead(fd);
      expr(fd, s_node);
      set_lookahead(fd);
      stmt(fd, s_node);
      set_lookahead(fd);
      if(lookahead == ELSE){
        stmt(fd, s_node);
      }else{
        ungetl();
      }
      break;
    case WHILE:
      s_node = mknode(WHILE);
      add_child_node(n, s_node);
      set_lookahead(fd);
      expr(fd, s_node);
      set_lookahead(fd);
      stmt(fd, s_node);
      break;
    case LBRACE:
      block(fd, prev);
      break;
    case INT:
      ungetl();
      vdl(fd, n);
      break;
    case CHAR:
      ungetl();
      vdl(fd, n);
      break;
    default:
      ungetl();
      expr(fd, n);
      set_lookahead(fd);
      break;
  }
}


/*
  The expression grammar has some problems.

  If you use parentheses the expression will evaluate correctly.
  If you don't, things might go wrong.
*/
void expr(FILE *fd, ast_node *parent){
  ast_node *n = mknonterm(EXPR_DEC_LIST);
  add_child_node(parent, n);
  e1(fd, n);
  assign(fd, n);
}

void e1(FILE *fd, ast_node *parent){
  e2(fd, parent);
  e1p(fd, parent);
}

void e1p(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  if(lookahead == OR){
    ast_node *n = mknode(OR);
    add_child_node(parent, n);
    e2(fd, n);
    e1p(fd, n);
  }else{
    ungetl();
  }
}

void e2(FILE *fd, ast_node *parent){
  e3(fd, parent);
  e2p(fd, parent);
}

void e2p(FILE *fd, ast_node *parent){
  set_lookahead(fd);
  
  if(lookahead == AND){
    ast_node *n = mknode(AND);
    add_child_node(parent, n);
    e3(fd, n);
    e2p(fd, n);
  }else{
    ungetl();
  }
}

void e3(FILE *fd, ast_node *parent){
  e4(fd, parent);
  e3p(fd, parent);
}

void e3p(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n;
  switch(lookahead){
    case EQ:
      n = mknode(EQ);
      add_child_node(parent, n);
      e4(fd, n);
      e3p(fd, n);
      break;
    case NE:
      n = mknode(NE);
      add_child_node(parent, n);
      e4(fd, n);
      e3p(fd, n);
      break;
    default:
      ungetl();
      break;
  }
}

void e4(FILE *fd, ast_node *parent){
  e5(fd, parent);
  e4p(fd, parent);
}

void e4p(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n;
  switch(lookahead){
    case LT:
      n = mknode(LT);
      add_child_node(parent, n);
      e5(fd, n);
      e4p(fd, n);
      break;
    case LE:
      n = mknode(LE);
      add_child_node(parent, n);
      e5(fd, n);
      e4p(fd, n);
      break;
    case GT:
      n = mknode(GT);
      add_child_node(parent, n);
      e5(fd, n);
      e4p(fd, n);
      break;
    case GE:
      n = mknode(GE);
      add_child_node(parent, n);
      e5(fd, n);
      e4p(fd, n);
      break;
    default:
      ungetl();
      break;
  }
}

void e5(FILE *fd, ast_node *parent){
  e6(fd, parent);
  e5p(fd, parent);
}

void e5p(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n;
  switch(lookahead){
    case PLUS:
      n = mknode(PLUS);
      add_child_node(parent, n);
      e6(fd, n);
      e5p(fd, n);
      break;
    case MINUS:
      n = mknode(MINUS);
      add_child_node(parent, n);
      e6(fd, n);
      e5p(fd, n);
      break;
    default:
      ungetl();
      break;
  }
}

void e6(FILE *fd, ast_node *parent){
  e7(fd, parent);
  e6p(fd, parent);
}

void e6p(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n;
  switch(lookahead){
    case MULT:
      n = mknode(MULT);
      add_child_node(parent, n);
      e7(fd, n);
      e6p(fd, n);
      break;
    case DIV:
      n = mknode(DIV);
      add_child_node(parent, n);
      e7(fd, n);
      e6p(fd, n);
      break;
    default:
      ungetl();
      break;
  }
}

void e7(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n;
  switch(lookahead){
    case NOT:
      n = mknode(NOT);
      add_child_node(parent, n);
      e7(fd, n);
      break;
    case MINUS:
      n = mknode(MINUS);
      add_child_node(parent, n);
      e7(fd, n);
      break;
    default:
      ungetl();
      e8(fd, parent);
      break;
  }
}

void e8(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n;
  switch(lookahead){
    case NUM:
      add_child_node(parent, mknode(NUM));
      break;
    case LPAREN:
      expr(fd, prev);
      set_lookahead(fd);
      break;
    case ID:
      add_child_node(parent, mknode(ID));
      e8p(fd, parent);
      break;
  }
}

void e8p(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n;
  switch(lookahead){
    case LPAREN:
      add_child_node(parent, mknode(LPAREN));
      exprlist(fd, prev);
      set_lookahead(fd);
      break;
    case LBRACK:
      add_child_node(parent, mknode(LBRACK));
      expr(fd, prev);
      set_lookahead(fd);
      add_child_node(parent, mknode(RBRACK));
      break;
    default:
      ungetl();
      break;
  }
}

void assign(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  ast_node *n;
  switch(lookahead){
    case ASSIGN:
      add_child_node(parent, mknode(ASSIGN));
      expr(fd, prev);
      break;
    default:
      ungetl();
      break;
  }
}

void exprlist(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  //ugly, I know, I'm sorry
  if(lookahead == OR || lookahead == AND || lookahead == EQ || lookahead == NE || lookahead == GT || lookahead == GE || lookahead == LT || lookahead == LE || lookahead == PLUS || lookahead == MINUS || lookahead == MULT || lookahead == DIV || lookahead == NOT || lookahead == NUM || lookahead == LPAREN || lookahead == ID || lookahead == LBRACK){
    ungetl();
    expr(fd, parent);
    elp(fd, parent);
  }else{
    ungetl();
  }
}

void elp(FILE *fd, ast_node *parent){
  set_lookahead(fd);

  if(lookahead == COMMA){
    exprlist(fd, parent);
  }else{
    ungetl();
  }
}