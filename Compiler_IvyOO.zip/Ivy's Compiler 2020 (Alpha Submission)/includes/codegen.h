#ifndef _CODEGEN_H
#define _CODEGEN_H


// you likely will need to include other 
// header files from your compiler here
#include "lexer.h"
#include "ast.h"
#include "parser.h"

#define MAX_LINES 10000		//The maximum number of lines of assembly we can write
#define MAX_LINE_LEN 100	//The maximum length of a line of assembly code

extern char code_table[MAX_LINES][MAX_LINE_LEN];

void generate_code_from_codetable(FILE *out);

#endif
