#ifndef _SYMTAB_H
#define _SYMTAB_H

#define MAX_STACK_LEN 100
#define MAX_NUM_STACKS 100

//The Stack Structure (each entry in the Table structure is one of these)
struct Stack {
	int top;	//Points to the highest, empty value on the stack
	int addresses[MAX_STACK_LEN];	//The stack itself
	unsigned long hash;	//The hash associated with this variable name
};

typedef struct Stack Stack;



//The Table Structure (holds everything in the symbol table)
struct Table {
	int top;
	Stack stacks[MAX_NUM_STACKS];	//The table of stacks itself
};

typedef struct Table Table;

#endif
